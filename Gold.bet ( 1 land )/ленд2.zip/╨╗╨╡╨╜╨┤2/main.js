
document.querySelector('video').play();

checkSize();

function parallax(event) {
    this.querySelectorAll('.layer').forEach(layer => {
        let speed = layer.getAttribute('data-speed');
        layer.style.transform = `translateX(${(event.clientX*speed/500)}px)`
    })
}

function checkSize() {
    document.querySelectorAll('.layer').forEach(layer => {
        let speed = layer.getAttribute('data-speed');
        if (window.innerWidth < window.innerHeight) {
            if ( speed == 50 ) {
                layer.style.backgroundImage = "url('img/metafan-vert.png";
            } else {
                layer.style.backgroundImage = "url('img/object-vert.png";
            }
        } else {
            if ( speed == 50 ) {
                layer.style.backgroundImage = "url('img/metafan.png";
            } else {
                layer.style.backgroundImage = "url('img/object.png";
            }
        }
    })
}


document.body.onresize = checkSize;
document.addEventListener('mousemove', parallax);